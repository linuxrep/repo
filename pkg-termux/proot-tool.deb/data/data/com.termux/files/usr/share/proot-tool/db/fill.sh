#!/bin/bash

path="proot.db"

function setup_database() {
    # Erstelle die proot.db-Datenbank und die proot_data-Tabelle, wenn sie nicht existieren
    sqlite3 "$path" "CREATE TABLE IF NOT EXISTS proot_data (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        search TEXT NOT NULL,
                        url TEXT NOT NULL,
                        arch TEXT NOT NULL,
                        sha TEXT NOT NULL
                    );"
}

function manuell() {
    read -p "Name: " name
    read -p "URL: " url
    read -p "Architektur: " arch
    read -p "SHA256-Summe: " sha
    # Füge die Daten in die Datenbank ein
    sqlite3 "$path" "INSERT INTO proot_data (search, url, arch, sha) VALUES ('$name', '$url', '$arch', '$sha');"
}

function auto() {
    name="$1"
    url="$2"
    arch="$3"
    sha="$4"
    # Füge die Daten in die Datenbank ein
    sqlite3 "$path" "INSERT INTO proot_data (search, url, arch, sha) VALUES ('$name', '$url', '$arch', '$sha');"
}

if [ "$1" = "--setup" ]; then
    setup_database
elif [ "$1" = "--manuell" ]; then
    manuell
elif [ "$1" = "--auto" ]; then
    auto "$2" "$3" "$4" "$5"
else
    echo "Not Valid"
fi
