#!/bin/bash
path="proot.db"

function manuell() {
    read -p "name: " name
    read -p "url: " url
    sqlite3 "$path" "INSERT INTO proot_data (search, url) VALUES ('$name', '$url');"
}

function auto() {
    name="$1"
    url="$2"
    sqlite3 "$path" "INSERT INTO proot_data (search, url) VALUES ('$name', '$url');"
}

if [ "$1" = "--manuell" ]; then
    manuell
elif [ "$1" = "--auto" ]; then
    auto "$2" "$3"
else
    echo "Not Valid"
fi